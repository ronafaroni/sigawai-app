<tbody id="kehadiran-table-body">
    @if($kehadiran->isEmpty())
    <tr id="empty-row">
        <td colspan="7" class="text-center">Data kehadiran tidak ditemukan atau kosong</td>
    </tr>
    @else
        @foreach ($kehadiran as $data)
        <tr id="kehadiran-{{ $data->id_kehadiran }}">
            <td>{{ $loop->iteration }}</td>
            <td>
                <h2 class="table-avatar">
                    <img class="avatar-img" width="40px" height="40px"
                        src="{{ asset('wajah/' . $data->image_path) }}"
                        alt="User Image">
                </h2>
            </td>
            <td>{{ $data->niy }}</td>
            <td>{{ $data->nama_pegawai }}</td>
            <td>{{ $data->tanggal_masuk }}</td>
            <td>{{ $data->waktu_masuk }}</td>
            <td class="d-flex align-items-center"> 
                <button data-id="{{ $data->id_kehadiran }}" class="btn btn-import me-2 delete-kehadiran"><i class="fa fa-trash me-1"></i></button>
            </td>
        </tr>
        @endforeach
    @endif
</tbody>


<script>
    document.addEventListener('click', function(event) {
    if (event.target.closest('.delete-kehadiran')) {
        if (confirm('Apakah anda yakin ingin menghapus data kehadiran ?')) {
            const button = event.target.closest('.delete-kehadiran');
            const id = button.getAttribute('data-id');

            fetch(`/kehadiran/${id}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                },
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    // Hapus baris dari tabel
                    document.getElementById(`kehadiran-${id}`).remove();

                    // Cek apakah ada baris yang tersisa di tabel
                    if (document.querySelectorAll('#kehadiran-table-body tr').length === 0) {
                        // Tambahkan baris data kosong
                        const emptyRow = document.createElement('tr');
                        emptyRow.id = 'empty-row';
                        emptyRow.innerHTML = '<td colspan="7" class="text-center">Data kehadiran tidak ditemukan atau kosong</td>';
                        document.getElementById('kehadiran-table-body').appendChild(emptyRow);
                    }
                } else {
                    alert('Gagal menghapus data: ' + data.error);
                }
            })
            .catch(error => console.error('Error:', error));
        }
    }
});

</script>
